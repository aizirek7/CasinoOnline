package com.onlinegames.qcasino.fragments

object Utils {
    const val ShearedPref = "shearedPref"
    const val TAG = "TAG"
    const val KEY_FOR_SP = "key"
    const val URL = "https://greenslots.ru/WkyDrQSN"
    const val URL_FROM_URL = "url"
    const val SCORE = "score"
    const val IMAGE_URL = "https://disk.yandex.ru/d/S9Ocf8Hzx22Z_g"
}